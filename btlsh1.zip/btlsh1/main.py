from random import randint
board = []
for x in range(0, 5):
    board.append(["[0]"] * 5)

def print_board(board):
  for row in board:
    print (" ".join(row))

print_board(board)

def random_row(board):
    return randint(0, len(board) - 1)
def random_column(board):
    return randint(0, len(board[0]) - 1)

ship_row = random_row(board)
ship_column = random_column(board)
print(ship_column)
print(ship_row)

for turn in range(4):
    print("turn no:", turn+1)
    user_guess_row = int(input("Guess the row:"))
    user_guess_column = int(input("Guess the column:"))

    if user_guess_column == ship_column and user_guess_row == ship_row:
        print("WOW!! you sank the ship!")
        break

    else:
      if user_guess_row not in range(5) or \
      user_guess_column not in range(5):
        print("Too bad you hit the ocean")
      elif board[user_guess_row][user_guess_column] == "X":
        print("You have already hit that")
      else:
        print("You missed!!")
        board[user_guess_row][user_guess_column] = "[X]"

        if turn == 4:
            print("GAME OVER!")
        print_board(board)
